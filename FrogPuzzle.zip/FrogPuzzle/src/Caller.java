/**DISCLAIMER: The credit for the idea of the Game belongs 
   to Giyomu Games of its creation "Frog Puzzle" on Google Play

   The idea of the structure of coding a Java Game comes from youtube tutorial
   by #RealTutsGML called "Java Beginner Tutorial"
**/

/**
 * This class is the main class of the project
 * @author jia
 */
public class Caller {
	
	public static void main(String[] args) {
		MainPage mp = new MainPage();

	}

}
